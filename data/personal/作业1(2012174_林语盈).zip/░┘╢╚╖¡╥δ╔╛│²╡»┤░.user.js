// ==UserScript==
// @name         百度翻译删除弹窗
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       lyy
// @match        http://*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
  document.getElementsByClassName('desktop-guide')[0].remove();
  document.getElementsByClassName('download-app')[0].remove();
})();