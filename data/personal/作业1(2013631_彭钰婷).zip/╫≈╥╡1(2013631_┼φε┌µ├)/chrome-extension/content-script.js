var seconds = 0;
var perm = 1;
myf = (event) => {
    if(!perm){
        alert("休息期间, 请勿使用电脑")
    }
}
function reset(){
    perm = (perm === 1) ? 0 : 1;
    seconds = 0;//重新开始计时
}

function timeelapse(){
    seconds++;
    if(seconds > 2700){
        // 浏览器支持且用户没有禁止浏览器通知的情况下执行
        if(window.Notification && Notification.permission !== "denied") {
            Notification.requestPermission(function(status) {
                var n = new Notification('护眼时间到', { body: '您已连续工作45min, 请休息5min' }); 
                n.onshow = function () {
                    setTimeout(n.close.bind(n), 300000); //5min后关闭通知
                    perm = 0;//在这5min内无法点击网页
                    setTimeout(reset, 300000);
               }
            });
        }
        else{
            alert("不提供notification功能")
        }
        seconds = 0;
    }
    
}
chrome.runtime.onMessage.addListener((message) => {
    if(message.extension === 'ON'){
        setInterval(timeelapse, 1000);
        document.addEventListener('click',myf)
    }
    else{
        document.removeEventListener('click',myf)
    }
});
console.log('You have opened the extension.')
