// ==UserScript==
// @name         我的脚本（CSDN去除广告）
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include      *csdn.net/*
// @match        *csdn.net/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==
/* eslint-env jquery */
(function() {
    'use strict';

    // 屏蔽 “广告
    function myfunc() {
        const arr = $.merge($('#content_left span'), $('#content_left a.c-color-gray'));
        $.each(arr, function(idx, el) {
            const container = $(el).parents('.c-container');
            if (el.innerText.indexOf('广告') !== -1 && container.css('display') !== 'none') {
                container.css('display', 'none');
            }
        });
    }


    // 启用功能
    $(function() {
        myfunc();
    });

})();